import { Link, useLocation } from "wouter";
import { LayoutDashboard, Calendar, CalendarPlus, BrainCircuit, Building2 } from "lucide-react";
import { cn } from "@/lib/utils";

export function Shell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navigation = [
    { name: "Dashboard", href: "/", icon: LayoutDashboard },
    { name: "All Events", href: "/events", icon: Calendar },
    { name: "Plan Event", href: "/events/new", icon: CalendarPlus },
    { name: "ML Predictor", href: "/predict", icon: BrainCircuit },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row font-sans">
      <aside className="w-full md:w-64 bg-sidebar border-b md:border-r border-sidebar-border flex-shrink-0">
        <div className="p-6">
          <div className="flex items-center gap-3 font-semibold text-sidebar-foreground">
            <div className="bg-sidebar-primary text-sidebar-primary-foreground p-2 rounded-lg">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="leading-tight">Capacity Planner</div>
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono mt-0.5">MTech Week 1 AI/ML</div>
            </div>
          </div>
        </div>
        <nav className="px-4 pb-6 space-y-1">
          {navigation.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </aside>
      <main className="flex-1 min-w-0 overflow-auto">
        <div className="max-w-7xl mx-auto p-6 md:p-8 lg:p-10">
          {children}
        </div>
      </main>
    </div>
  );
}
