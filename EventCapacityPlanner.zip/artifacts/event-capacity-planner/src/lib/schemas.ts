import { z } from "zod";

export const eventFormSchema = z.object({
  name: z.string().min(1, "Event name is required"),
  eventType: z.enum([
    "conference",
    "seminar",
    "workshop",
    "team_building",
    "product_launch",
    "networking",
    "training",
    "annual_dinner"
  ], { required_error: "Please select an event type" }),
  date: z.string().min(1, "Date is required"),
  venue: z.string().min(1, "Venue is required"),
  capacity: z.coerce.number().min(1, "Capacity must be at least 1"),
  notes: z.string().optional()
});

export type EventFormValues = z.infer<typeof eventFormSchema>;

export const predictionFormSchema = z.object({
  eventType: z.enum([
    "conference",
    "seminar",
    "workshop",
    "team_building",
    "product_launch",
    "networking",
    "training",
    "annual_dinner"
  ], { required_error: "Please select an event type" }),
  capacity: z.coerce.number().min(1, "Capacity must be at least 1"),
  date: z.string().min(1, "Date is required"),
  venue: z.string().min(1, "Venue is required"),
});

export type PredictionFormValues = z.infer<typeof predictionFormSchema>;
