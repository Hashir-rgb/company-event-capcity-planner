import { useGetEventsSummary, useGetEventsAnalytics, usePredictAttendance } from "@workspace/api-client-react";
import { DashboardSkeleton } from "@/components/layout/skeletons";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { cn, formatNumber, formatPercent } from "@/lib/utils";
import { Users, Calendar as CalendarIcon, CheckCircle2, TrendingUp, ArrowRight } from "lucide-react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell } from "recharts";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { data: summary, isLoading: isLoadingSummary } = useGetEventsSummary();
  const { data: analytics, isLoading: isLoadingAnalytics } = useGetEventsAnalytics();

  if (isLoadingSummary || isLoadingAnalytics) {
    return <DashboardSkeleton />;
  }

  if (!summary || !analytics) {
    return <div>Failed to load dashboard data.</div>;
  }

  const statCards = [
    {
      title: "Total Capacity",
      value: formatNumber(summary.totalCapacity),
      description: "Across all active events",
      icon: Users,
      trend: "+12%",
    },
    {
      title: "Upcoming Events",
      value: formatNumber(summary.upcomingEvents),
      description: "Next 30 days",
      icon: CalendarIcon,
      trend: "4 needed",
    },
    {
      title: "Completed Events",
      value: formatNumber(summary.completedEvents),
      description: "Year to date",
      icon: CheckCircle2,
    },
    {
      title: "Avg. Predicted Utilization",
      value: formatPercent(summary.averageUtilization),
      description: "Based on ML predictions",
      icon: TrendingUp,
      valueClass: "text-primary",
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground mt-1 text-sm">
          Overview of your event portfolio and attendance predictions.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, i) => (
          <Card key={i} className="border-l-4 border-l-transparent hover:border-l-primary transition-all">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                  <p className={cn("text-3xl font-bold font-mono tracking-tight", stat.valueClass)}>
                    {stat.value}
                  </p>
                </div>
                <div className="p-2 bg-primary/10 text-primary rounded-md">
                  <stat.icon className="w-5 h-5" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-4 flex items-center gap-1">
                {stat.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 flex flex-col">
          <CardHeader>
            <CardTitle>Attendance by Event Type</CardTitle>
            <CardDescription>Average predicted vs actual capacity</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics} margin={{ top: 20, right: 0, left: 0, bottom: 0 }}>
                <XAxis 
                  dataKey="eventType" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false}
                  tickFormatter={(val) => val.split('_').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                />
                <YAxis fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  cursor={{ fill: 'var(--color-muted)', opacity: 0.4 }}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-md)' }}
                />
                <Bar dataKey="avgCapacity" name="Avg Capacity" fill="hsl(var(--muted))" radius={[4, 4, 0, 0]} />
                <Bar dataKey="avgAttendance" name="Avg Attendance" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Recent Events</CardTitle>
            <CardDescription>Latest planned and completed</CardDescription>
          </CardHeader>
          <CardContent className="flex-1">
            <div className="space-y-5">
              {summary.recentEvents?.slice(0, 5).map(event => (
                <div key={event.id} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none truncate max-w-[150px]">
                      <Link href={`/events/${event.id}`} className="hover:underline">
                        {event.name}
                      </Link>
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(new Date(event.date))}
                    </p>
                  </div>
                  <Badge variant={
                    event.status === 'completed' ? 'success' :
                    event.status === 'upcoming' ? 'default' : 'secondary'
                  } className="text-[10px] capitalize">
                    {event.status}
                  </Badge>
                </div>
              ))}
              {(!summary.recentEvents || summary.recentEvents.length === 0) && (
                <div className="text-sm text-muted-foreground text-center py-4">No events found</div>
              )}
            </div>
            <div className="mt-6">
              <Link href="/events" className="w-full">
                <Button variant="outline" className="w-full text-xs">
                  View All Events <ArrowRight className="w-3 h-3 ml-2" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
