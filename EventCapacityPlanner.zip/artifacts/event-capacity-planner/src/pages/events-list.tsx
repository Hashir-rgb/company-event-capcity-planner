import { useListEvents } from "@workspace/api-client-react";
import { TableSkeleton } from "@/components/layout/skeletons";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { CalendarPlus, Search, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useState } from "react";

export default function EventsList() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  
  const { data: events, isLoading } = useListEvents();

  if (isLoading) {
    return <TableSkeleton />;
  }

  let filteredEvents = events || [];
  
  if (statusFilter !== "all") {
    filteredEvents = filteredEvents.filter(e => e.status === statusFilter);
  }
  
  if (search) {
    const q = search.toLowerCase();
    filteredEvents = filteredEvents.filter(e => 
      e.name.toLowerCase().includes(q) || 
      e.venue.toLowerCase().includes(q) ||
      e.eventType.toLowerCase().includes(q)
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">All Events</h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Manage your event portfolio and monitor attendance utilization.
          </p>
        </div>
        <Link href="/events/new">
          <Button>
            <CalendarPlus className="w-4 h-4 mr-2" />
            Plan New Event
          </Button>
        </Link>
      </div>

      <Card>
        <div className="p-4 border-b border-border flex flex-col sm:flex-row gap-4 items-center bg-muted/20">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search events, venues..." 
              className="pl-9 bg-background"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <Select 
              value={statusFilter} 
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-[150px] bg-background"
            >
              <option value="all">All Statuses</option>
              <option value="upcoming">Upcoming</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </Select>
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/30">
              <TableHead>Event</TableHead>
              <TableHead>Date & Venue</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[200px]">Capacity Utilization</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredEvents.map(event => {
              const attendance = event.actualAttendance || event.predictedAttendance || 0;
              const utilization = event.capacity > 0 ? (attendance / event.capacity) * 100 : 0;
              const isPredicted = !event.actualAttendance && event.predictedAttendance;
              
              return (
                <TableRow key={event.id}>
                  <TableCell>
                    <div className="font-medium text-foreground">{event.name}</div>
                    <div className="text-xs text-muted-foreground capitalize">
                      {event.eventType.replace('_', ' ')}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      {new Intl.DateTimeFormat('en-US', { 
                        year: 'numeric', month: 'short', day: 'numeric' 
                      }).format(new Date(event.date))}
                    </div>
                    <div className="text-xs text-muted-foreground truncate max-w-[150px]">
                      {event.venue}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={
                      event.status === 'completed' ? 'success' :
                      event.status === 'upcoming' ? 'default' : 'secondary'
                    } className="capitalize text-[10px] py-0">
                      {event.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs">
                        <span className="font-mono">
                          {Math.round(utilization)}%
                        </span>
                        <span className="text-muted-foreground text-[10px]">
                          {attendance} / {event.capacity}
                        </span>
                      </div>
                      <Progress 
                        value={Math.min(100, utilization)} 
                        indicatorColor={
                          utilization > 90 ? "bg-destructive" :
                          utilization < 40 ? "bg-amber-500" :
                          "bg-primary"
                        }
                      />
                      {isPredicted && (
                        <p className="text-[9px] text-muted-foreground text-right italic">
                          Predicted
                        </p>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Link href={`/events/${event.id}`}>
                      <Button variant="ghost" size="sm">Details</Button>
                    </Link>
                  </TableCell>
                </TableRow>
              );
            })}
            {filteredEvents.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                  No events found matching your criteria.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
