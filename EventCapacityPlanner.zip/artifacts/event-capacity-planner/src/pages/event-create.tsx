import { useCreateEvent, usePredictAttendance, getListEventsQueryKey, getGetEventsSummaryQueryKey } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { eventFormSchema, type EventFormValues } from "@/lib/schemas";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { BrainCircuit, Loader2, Sparkles, TrendingUp, AlertTriangle } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Progress } from "@/components/ui/progress";
import { useQueryClient } from "@tanstack/react-query";

export default function EventCreate() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const createEvent = useCreateEvent();
  const predictAttendance = usePredictAttendance();
  
  const [prediction, setPrediction] = useState<any>(null);
  
  const form = useForm<EventFormValues>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      name: "",
      eventType: undefined,
      date: "",
      venue: "",
      capacity: 0,
      notes: ""
    }
  });

  const { watch } = form;
  const watchedEventType = watch("eventType");
  const watchedCapacity = watch("capacity");
  const watchedDate = watch("date");
  const watchedVenue = watch("venue");

  const predictTimeoutRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => {
    if (watchedEventType && watchedCapacity > 0 && watchedDate && watchedVenue) {
      if (predictTimeoutRef.current) {
        clearTimeout(predictTimeoutRef.current);
      }
      
      predictTimeoutRef.current = setTimeout(() => {
        predictAttendance.mutate({
          data: {
            eventType: watchedEventType as any,
            capacity: watchedCapacity,
            date: watchedDate,
            venue: watchedVenue
          }
        }, {
          onSuccess: (data) => {
            setPrediction(data);
          }
        });
      }, 800); // debounce
    }
  }, [watchedEventType, watchedCapacity, watchedDate, watchedVenue]);

  function onSubmit(values: EventFormValues) {
    createEvent.mutate({
      data: {
        ...values,
        predictedAttendance: prediction?.predictedAttendance || null
      }
    }, {
      onSuccess: (data) => {
        toast({
          title: "Event Planned Successfully",
          description: `Created ${data.name} with predicted attendance of ${data.predictedAttendance || 'unknown'}.`
        });
        queryClient.invalidateQueries({ queryKey: getListEventsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetEventsSummaryQueryKey() });
        setLocation(`/events/${data.id}`);
      },
      onError: () => {
        toast({
          title: "Error",
          description: "Failed to create event. Please try again.",
          variant: "destructive"
        });
      }
    });
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Plan New Event</h1>
        <p className="text-muted-foreground mt-1 text-sm">
          Define event parameters and get real-time ML capacity predictions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)}>
                <CardHeader>
                  <CardTitle>Event Details</CardTitle>
                  <CardDescription>All fields are required to generate an accurate ML prediction.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Event Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Q3 Quarterly Business Review" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="eventType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Event Type</FormLabel>
                          <Select 
                            value={field.value} 
                            onChange={(e) => field.onChange(e.target.value)}
                          >
                            <option value="" disabled>Select Type</option>
                            <option value="conference">Conference</option>
                            <option value="seminar">Seminar</option>
                            <option value="workshop">Workshop</option>
                            <option value="team_building">Team Building</option>
                            <option value="product_launch">Product Launch</option>
                            <option value="networking">Networking</option>
                            <option value="training">Training</option>
                            <option value="annual_dinner">Annual Dinner</option>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="venue"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Venue</FormLabel>
                          <FormControl>
                            <Input placeholder="Main Hall A" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="capacity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Maximum Capacity</FormLabel>
                          <FormControl>
                            <Input type="number" min={1} placeholder="250" {...field} />
                          </FormControl>
                          <FormDescription>Physical room limit</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes (Optional)</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Dietary restrictions, VIPs expected..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
                <CardFooter className="bg-muted/30 py-4 flex justify-end">
                  <Button type="submit" disabled={createEvent.isPending}>
                    {createEvent.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    Create Event
                  </Button>
                </CardFooter>
              </form>
            </Form>
          </Card>
        </div>

        <div>
          <div className="sticky top-6">
            <Card className="border-primary/20 shadow-md">
              <CardHeader className="bg-primary/5 pb-4 border-b border-primary/10">
                <CardTitle className="flex items-center gap-2 text-primary text-lg">
                  <Sparkles className="w-5 h-5" />
                  Live ML Prediction
                </CardTitle>
                <CardDescription>Fills automatically as you type</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                {predictAttendance.isPending ? (
                  <div className="flex flex-col items-center justify-center py-8 text-muted-foreground space-y-4">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                    <p className="text-sm font-mono">Running model inference...</p>
                  </div>
                ) : prediction ? (
                  <div className="space-y-6">
                    <div className="text-center">
                      <p className="text-sm font-medium text-muted-foreground mb-1">Predicted Attendance</p>
                      <div className="text-5xl font-bold font-mono text-foreground">
                        {prediction.predictedAttendance}
                      </div>
                      <p className="text-xs text-muted-foreground mt-2 flex items-center justify-center gap-1">
                        <BrainCircuit className="w-3 h-3" />
                        Confidence Score: {Math.round(prediction.confidenceScore * 100)}%
                      </p>
                    </div>

                    <div className="space-y-2 pt-4 border-t border-border">
                      <div className="flex justify-between text-sm">
                        <span>Expected Utilization</span>
                        <span className="font-mono">{Math.round(prediction.utilizationRate)}%</span>
                      </div>
                      <Progress 
                        value={prediction.utilizationRate} 
                        indicatorColor={
                          prediction.utilizationRate > 95 ? "bg-destructive" :
                          prediction.utilizationRate < 50 ? "bg-amber-500" :
                          "bg-primary"
                        }
                      />
                      {prediction.utilizationRate > 95 && (
                        <p className="text-[11px] text-destructive flex items-center gap-1 mt-1">
                          <AlertTriangle className="w-3 h-3" /> High risk of overcapacity
                        </p>
                      )}
                      {prediction.utilizationRate < 50 && (
                        <p className="text-[11px] text-amber-500 flex items-center gap-1 mt-1">
                          <AlertTriangle className="w-3 h-3" /> Poor resource utilization
                        </p>
                      )}
                    </div>

                    <div className="bg-muted p-4 rounded-md">
                      <p className="text-sm font-medium flex items-center gap-2 mb-2">
                        <TrendingUp className="w-4 h-4 text-primary" />
                        Recommendation
                      </p>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {prediction.recommendation}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-10 text-center space-y-3">
                    <div className="p-3 bg-muted rounded-full">
                      <BrainCircuit className="w-6 h-6 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Awaiting Data</p>
                      <p className="text-xs text-muted-foreground mt-1 max-w-[200px] mx-auto">
                        Fill in event type, date, venue, and capacity to see prediction.
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
