import { useGetEvent, useUpdateEvent, useDeleteEvent, usePredictAttendance, getListEventsQueryKey, getGetEventsSummaryQueryKey, getGetEventQueryKey } from "@workspace/api-client-react";
import { useParams, useLocation } from "wouter";
import { DetailSkeleton } from "@/components/layout/skeletons";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, BrainCircuit, Calendar, MapPin, Users, Activity, Trash2, Edit2, CheckCircle2, TrendingUp, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { formatNumber, formatPercent } from "@/lib/utils";
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip } from "recharts";
import { 
  AlertDialog, 
  AlertDialogAction, 
  AlertDialogCancel, 
  AlertDialogContent, 
  AlertDialogDescription, 
  AlertDialogFooter, 
  AlertDialogHeader, 
  AlertDialogTitle, 
  AlertDialogTrigger 
} from "@/components/ui/alert-dialog";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

export default function EventDetail() {
  const { id } = useParams<{ id: string }>();
  const eventId = parseInt(id || "0", 10);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: event, isLoading } = useGetEvent(eventId, {
    query: { enabled: !!eventId, queryKey: getGetEventQueryKey(eventId) }
  });
  
  const updateEvent = useUpdateEvent();
  const deleteEvent = useDeleteEvent();
  const predictAttendance = usePredictAttendance();

  const [predictionResult, setPredictionResult] = useState<any>(null);

  useEffect(() => {
    // Once we have event data, fetch its ML prediction for feature breakdown
    if (event && !predictionResult && !predictAttendance.isPending) {
      predictAttendance.mutate({
        data: {
          eventType: event.eventType as any,
          capacity: event.capacity,
          date: event.date,
          venue: event.venue
        }
      }, {
        onSuccess: (data) => setPredictionResult(data)
      });
    }
  }, [event]);

  if (isLoading) {
    return <DetailSkeleton />;
  }

  if (!event) {
    return <div className="text-center py-20">Event not found.</div>;
  }

  const handleDelete = () => {
    deleteEvent.mutate({ id: eventId }, {
      onSuccess: () => {
        toast({ title: "Event deleted", description: "The event has been permanently removed." });
        queryClient.invalidateQueries({ queryKey: getListEventsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetEventsSummaryQueryKey() });
        setLocation("/events");
      }
    });
  };

  const handleStatusChange = (newStatus: "upcoming" | "completed" | "cancelled") => {
    updateEvent.mutate({
      id: eventId,
      data: { status: newStatus }
    }, {
      onSuccess: () => {
        toast({ title: "Status updated", description: `Event status changed to ${newStatus}.` });
        queryClient.invalidateQueries({ queryKey: getListEventsQueryKey() });
      }
    });
  };

  const attendance = event.actualAttendance || event.predictedAttendance || 0;
  const utilization = event.capacity > 0 ? (attendance / event.capacity) * 100 : 0;
  const isPredicted = !event.actualAttendance && event.predictedAttendance;

  return (
    <div className="space-y-6 max-w-6xl mx-auto animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
        <div className="space-y-1 text-sm text-muted-foreground mb-2 flex items-center gap-2">
          <Link href="/events" className="hover:text-foreground flex items-center gap-1">
            <ArrowLeft className="w-4 h-4" /> Back to Events
          </Link>
        </div>
      </div>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold tracking-tight">{event.name}</h1>
            <Badge variant={
              event.status === 'completed' ? 'success' :
              event.status === 'upcoming' ? 'default' : 'secondary'
            } className="capitalize text-xs px-2">
              {event.status}
            </Badge>
          </div>
          <p className="text-muted-foreground mt-1 text-sm capitalize">
            {event.eventType.replace('_', ' ')}
          </p>
        </div>
        
        <div className="flex gap-2">
          {event.status === 'upcoming' && (
            <Button variant="outline" onClick={() => handleStatusChange('completed')}>
              <CheckCircle2 className="w-4 h-4 mr-2" /> Mark Completed
            </Button>
          )}
          {event.status === 'upcoming' && (
            <Button variant="outline" onClick={() => handleStatusChange('cancelled')}>
              <AlertCircle className="w-4 h-4 mr-2" /> Cancel Event
            </Button>
          )}
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="icon">
                <Trash2 className="w-4 h-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the event
                  and remove its data from all capacity analytics.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete} disabled={deleteEvent.isPending}>
                  Delete Event
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Event Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-muted p-2 rounded-md">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Date</p>
                      <p className="text-sm text-muted-foreground">
                        {new Intl.DateTimeFormat('en-US', { 
                          weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' 
                        }).format(new Date(event.date))}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-muted p-2 rounded-md">
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Venue</p>
                      <p className="text-sm text-muted-foreground">{event.venue}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-muted/30 p-4 rounded-lg border border-border">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium flex items-center gap-2">
                      <Users className="w-4 h-4" /> Attendance
                      {isPredicted && <Badge variant="outline" className="text-[10px] py-0 h-4">Predicted</Badge>}
                    </p>
                    <p className="font-mono text-sm">
                      {attendance} / {event.capacity}
                    </p>
                  </div>
                  <Progress 
                    value={Math.min(100, utilization)} 
                    className="h-2.5 mb-2"
                    indicatorColor={
                      utilization > 90 ? "bg-destructive" :
                      utilization < 40 ? "bg-amber-500" :
                      "bg-primary"
                    }
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{Math.round(utilization)}% Utilization</span>
                    <span>Max {event.capacity}</span>
                  </div>
                </div>
              </div>
              
              {event.notes && (
                <div className="mt-6 pt-6 border-t border-border">
                  <p className="text-sm font-medium mb-2">Notes</p>
                  <p className="text-sm text-muted-foreground bg-muted/20 p-4 rounded-md">
                    {event.notes}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between border-b border-border pb-4">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <BrainCircuit className="w-5 h-5 text-primary" />
                  ML Prediction Breakdown
                </CardTitle>
                <CardDescription>How the model arrived at its prediction</CardDescription>
              </div>
              {predictionResult && (
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Confidence</p>
                  <p className="text-xl font-bold font-mono text-primary">
                    {Math.round(predictionResult.confidenceScore * 100)}%
                  </p>
                </div>
              )}
            </CardHeader>
            <CardContent className="pt-6">
              {!predictionResult ? (
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Running analysis...
                </div>
              ) : (
                <div className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                    <div className="h-[250px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <RadarChart data={predictionResult.featureImportance}>
                          <PolarGrid stroke="hsl(var(--muted-foreground))" strokeOpacity={0.2} />
                          <PolarAngleAxis 
                            dataKey="feature" 
                            tick={{ fill: 'hsl(var(--foreground))', fontSize: 10 }}
                            tickFormatter={(val) => val.length > 10 ? val.substring(0,10)+'...' : val}
                          />
                          <Tooltip 
                            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-md)', fontSize: '12px' }}
                          />
                          <Radar 
                            name="Importance" 
                            dataKey="importance" 
                            stroke="hsl(var(--primary))" 
                            fill="hsl(var(--primary))" 
                            fillOpacity={0.3} 
                          />
                        </RadarChart>
                      </ResponsiveContainer>
                    </div>
                    
                    <div className="space-y-4">
                      <h4 className="text-sm font-medium border-b border-border pb-2">Feature Impact</h4>
                      <div className="space-y-3">
                        {predictionResult.featureImportance
                          .sort((a: any, b: any) => b.importance - a.importance)
                          .map((feature: any, i: number) => (
                          <div key={i} className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-2">
                              <div className={`w-2 h-2 rounded-full ${
                                feature.impact === 'positive' ? 'bg-emerald-500' : 
                                feature.impact === 'negative' ? 'bg-destructive' : 'bg-muted-foreground'
                              }`} />
                              <span className="capitalize">{feature.feature.replace(/([A-Z])/g, ' $1').trim()}</span>
                            </div>
                            <span className="font-mono text-muted-foreground">
                              {Math.round(feature.importance * 100)}%
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="bg-primary/5 border border-primary/20 p-4 rounded-lg">
                    <p className="text-sm font-medium flex items-center gap-2 mb-1 text-primary">
                      <Activity className="w-4 h-4" /> Model Recommendation
                    </p>
                    <p className="text-sm text-foreground/80">
                      {predictionResult.recommendation}
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start">
                <Edit2 className="w-4 h-4 mr-2" /> Edit Details
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Calendar className="w-4 h-4 mr-2" /> Add to Calendar
              </Button>
              {event.status === 'upcoming' && (
                <Button variant="default" className="w-full justify-start">
                  <Users className="w-4 h-4 mr-2" /> Enter Actual Attendance
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
