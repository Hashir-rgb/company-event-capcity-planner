import { usePredictAttendance } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { predictionFormSchema, type PredictionFormValues } from "@/lib/schemas";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { BrainCircuit, Loader2, Sparkles, TrendingUp, AlertTriangle, Activity } from "lucide-react";
import { useState } from "react";
import { Progress } from "@/components/ui/progress";
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar, Tooltip } from "recharts";

export default function MLPredictor() {
  const predictAttendance = usePredictAttendance();
  const [prediction, setPrediction] = useState<any>(null);
  
  const form = useForm<PredictionFormValues>({
    resolver: zodResolver(predictionFormSchema),
    defaultValues: {
      eventType: undefined,
      capacity: 0,
      date: "",
      venue: ""
    }
  });

  function onSubmit(values: PredictionFormValues) {
    predictAttendance.mutate({
      data: {
        eventType: values.eventType as any,
        capacity: values.capacity,
        date: values.date,
        venue: values.venue
      }
    }, {
      onSuccess: (data) => {
        setPrediction(data);
      }
    });
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-500">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-4">
          <BrainCircuit className="w-8 h-8" />
        </div>
        <h1 className="text-4xl font-bold tracking-tight mb-3">Capacity Predictor</h1>
        <p className="text-muted-foreground">
          Run "what-if" scenarios through our machine learning model before committing to an event plan. 
          Find the perfect venue size for your expected audience.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="border-sidebar-border shadow-sm">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <CardHeader>
                <CardTitle>Scenario Parameters</CardTitle>
                <CardDescription>Input hypothetical event details to run inference.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <FormField
                  control={form.control}
                  name="eventType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Event Type</FormLabel>
                      <Select 
                        value={field.value} 
                        onChange={(e) => field.onChange(e.target.value)}
                      >
                        <option value="" disabled>Select Type</option>
                        <option value="conference">Conference</option>
                        <option value="seminar">Seminar</option>
                        <option value="workshop">Workshop</option>
                        <option value="team_building">Team Building</option>
                        <option value="product_launch">Product Launch</option>
                        <option value="networking">Networking</option>
                        <option value="training">Training</option>
                        <option value="annual_dinner">Annual Dinner</option>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="capacity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Proposed Venue Capacity</FormLabel>
                      <FormControl>
                        <Input type="number" min={1} placeholder="e.g. 500" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormDescription>Seasonality affects predictions</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="venue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Venue / Location</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Downtown Convention Center" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
              <CardFooter className="bg-muted/30 py-4">
                <Button type="submit" className="w-full" disabled={predictAttendance.isPending}>
                  {predictAttendance.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4 mr-2" />
                  )}
                  Run Inference
                </Button>
              </CardFooter>
            </form>
          </Form>
        </Card>

        <div>
          {prediction ? (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
              <Card className="border-primary/20 bg-primary/5 shadow-md">
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <p className="text-sm font-medium text-primary mb-1 uppercase tracking-wider">Prediction Result</p>
                    <div className="text-6xl font-bold font-mono text-foreground tracking-tighter">
                      {prediction.predictedAttendance}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2 font-medium">
                      Expected Attendees
                    </p>
                  </div>

                  <div className="space-y-4 pt-4 border-t border-primary/10">
                    <div className="flex justify-between items-end text-sm">
                      <div>
                        <span className="text-muted-foreground block mb-1 text-xs">Utilization Rate</span>
                        <span className="font-mono font-medium">{Math.round(prediction.utilizationRate)}%</span>
                      </div>
                      <div className="text-right">
                        <span className="text-muted-foreground block mb-1 text-xs">Confidence</span>
                        <span className="font-mono font-medium">{Math.round(prediction.confidenceScore * 100)}%</span>
                      </div>
                    </div>
                    <Progress 
                      value={prediction.utilizationRate} 
                      indicatorColor={
                        prediction.utilizationRate > 95 ? "bg-destructive" :
                        prediction.utilizationRate < 50 ? "bg-amber-500" :
                        "bg-primary"
                      }
                      className="h-2 bg-primary/10"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Activity className="w-4 h-4" /> Feature Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[180px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={prediction.featureImportance}>
                        <PolarGrid stroke="hsl(var(--muted-foreground))" strokeOpacity={0.2} />
                        <PolarAngleAxis 
                          dataKey="feature" 
                          tick={{ fill: 'hsl(var(--foreground))', fontSize: 10 }}
                        />
                        <Tooltip />
                        <Radar 
                          name="Importance" 
                          dataKey="importance" 
                          stroke="hsl(var(--primary))" 
                          fill="hsl(var(--primary))" 
                          fillOpacity={0.3} 
                        />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                  
                  <div className="mt-4 bg-muted p-4 rounded-md">
                    <p className="text-sm font-medium flex items-center gap-2 mb-2">
                      <TrendingUp className="w-4 h-4 text-primary" />
                      Strategic Recommendation
                    </p>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {prediction.recommendation}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="h-full border-2 border-dashed border-muted rounded-xl flex flex-col items-center justify-center p-8 text-center bg-muted/10">
              <div className="p-4 bg-background rounded-full shadow-sm mb-4">
                <BrainCircuit className="w-8 h-8 text-muted-foreground/50" />
              </div>
              <h3 className="font-semibold mb-2">Ready for Inference</h3>
              <p className="text-sm text-muted-foreground max-w-[250px]">
                Fill out the scenario parameters and run the model to see predicted outcomes.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
