import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { Shell } from '@/components/layout/shell';
import Dashboard from '@/pages/dashboard';
import EventsList from '@/pages/events-list';
import EventCreate from '@/pages/event-create';
import EventDetail from '@/pages/event-detail';
import MLPredictor from '@/pages/predictor';

const queryClient = new QueryClient();

function Router() {
  return (
    <Shell>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/events" component={EventsList} />
        <Route path="/events/new" component={EventCreate} />
        <Route path="/events/:id" component={EventDetail} />
        <Route path="/predict" component={MLPredictor} />
        <Route component={NotFound} />
      </Switch>
    </Shell>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
