import { Router, type IRouter } from "express";
import healthRouter from "./health";
import eventsRouter from "./events";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/events", eventsRouter);

export default router;
